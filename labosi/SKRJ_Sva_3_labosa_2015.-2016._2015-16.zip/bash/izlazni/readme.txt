Neznam kako je išao zadatak točno ali mislim da je trebalo napisati skriptu kojoj se predaje
kao argument putanja do direktorija pa za svaku skriptu unutra ispisuje prvih n redova ili tako nešto
(nađite na fer2 skrj-1. labos 2015./2016 tamo je netko vjerojatno stavio).

Ovdje sam dobio 3/4 boda zato kaj nije skripta baš najbolja.
