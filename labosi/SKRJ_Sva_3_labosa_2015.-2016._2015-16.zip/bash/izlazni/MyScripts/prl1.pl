#!/usr/bin/perl -w

# Opis: prva skripta u Perlu
# Pozivanje: ./demo_1_perl.pl
# Autor: Larry Wall
