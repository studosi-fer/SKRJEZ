#!/bin/bash

# Opis: skripta služi za demonstraciju na Skriptnim jezicima
# Pozivanje: ./demo_1_ljuska.sh <src_dir> [<br_redaka>]
# Autor: Nepoznati Autor
