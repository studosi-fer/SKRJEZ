#!/bin/bash

# Opis: kopiranje kolekcije datoteka
# Pozivanje: ./demo_2_ljuska.sh <src_dir> <dst_dir>
# Autor: Bill Gates
