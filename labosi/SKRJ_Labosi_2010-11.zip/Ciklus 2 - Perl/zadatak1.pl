#!/usr/bin/perl

$niz = <stdin>;
$n = <stdin>;

print $niz x $n;