#!/bin/bash

if [ ! -d slike ]; then
    mkdir slike
fi
touch -m -t 201608011010 slike/IMG_2038.jpg
touch -m -t 201608090430 slike/IMG_2039.jpg
touch -m -t 201608080330 slike/IMG_2040.jpg
touch -m -t 201608060230 slike/IMG_2041.jpg
touch -m -t 201608061030 slike/IMG_2042.jpg
touch -m -t 201609250640 slike/IMG_2043.jpg
touch -m -t 201609200810 slike/IMG_2044.jpg
touch -m -t 201609150535 slike/IMG_2045.jpg
touch -m -t 201609100130 slike/IMG_2046.jpg
touch -m -t 201609050928 slike/IMG_2047.jpg


